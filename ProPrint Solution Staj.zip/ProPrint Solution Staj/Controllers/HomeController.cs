﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult aboutUS() { return View(); }
        public IActionResult VWX()
        {
            return View();
        }
        public IActionResult PUR()
        {
            return View();
        }
        public IActionResult MPS()
        {
            return View();
        }
        public IActionResult AMC()
        {
            return View();
        }
        public IActionResult Network()
        {
            return View();
        }
        public IActionResult DRS()
        {
            return View();
        }
        public IActionResult PS()
        {
            return View();
        }
        public IActionResult HP()
        {
            return View();
        }
        public IActionResult HPINK()
        {
            return View();
        }
        public IActionResult LENOVO()
        {
            return View();
        }
        public IActionResult IBM()
        {
            return View();
        }
        public IActionResult MSI()
        {
            return View();
        }
        public IActionResult EPSON()
        {
            return View();
        }
        public IActionResult DELL()
        {
            return View();
        }
        public IActionResult contactus()
        {
            return View();
        }
        public IActionResult Location()
        {
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
